import React, { useState } from 'react';
import { Plus, Megaphone, AlertCircle, Info, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { format } from 'date-fns';

interface AnnouncementManagerProps {
  selectedGroupId?: string;
}

export default function AnnouncementManager({ selectedGroupId }: AnnouncementManagerProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const { user } = useAuth();
  const { groups, announcements, addAnnouncement } = useData();

  const teacherGroups = groups.filter(group => group.teacherId === user?.id);
  
  // Filter announcements based on selected group
  const filteredAnnouncements = selectedGroupId
    ? announcements.filter(ann => ann.teacherId === user?.id && ann.groupId === selectedGroupId)
    : announcements.filter(ann => ann.teacherId === user?.id);

  const handleCreateAnnouncement = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    addAnnouncement({
      title: formData.get('title') as string,
      content: formData.get('content') as string,
      teacherId: user?.id || '',
      groupId: selectedGroupId || (formData.get('groupId') as string) || undefined,
      priority: formData.get('priority') as 'low' | 'medium' | 'high'
    });

    setShowCreateForm(false);
    e.currentTarget.reset();
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertCircle className="w-4 h-4" />;
      case 'medium':
        return <Info className="w-4 h-4" />;
      default:
        return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'haute priorité';
      case 'medium':
        return 'priorité moyenne';
      default:
        return 'faible priorité';
    }
  };

  const availableGroups = selectedGroupId 
    ? teacherGroups.filter(group => group.id === selectedGroupId)
    : teacherGroups;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">
          {selectedGroupId ? `Annonces - Groupe ${groups.find(g => g.id === selectedGroupId)?.name}` : 'Annonces Musicales'}
        </h2>
        <button
          onClick={() => setShowCreateForm(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Créer une Annonce
        </button>
      </div>

      {/* Formulaire de création d'annonce */}
      {showCreateForm && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Créer une Nouvelle Annonce</h3>
          <form onSubmit={handleCreateAnnouncement} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                Titre
              </label>
              <input
                type="text"
                id="title"
                name="title"
                className="input"
                placeholder="ex: Récital d'Hiver, Nouvelles Partitions Disponibles"
                required
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-2">
                Contenu
              </label>
              <textarea
                id="content"
                name="content"
                className="textarea"
                rows={4}
                placeholder="Rédigez votre annonce ici..."
                required
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {!selectedGroupId && (
                <div>
                  <label htmlFor="groupId" className="block text-sm font-medium text-gray-700 mb-2">
                    Groupe Ciblé (Optionnel)
                  </label>
                  <select
                    id="groupId"
                    name="groupId"
                    className="input"
                  >
                    <option value="">Tous les Groupes</option>
                    {availableGroups.map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-2">
                  Niveau de Priorité
                </label>
                <select
                  id="priority"
                  name="priority"
                  className="input"
                  required
                >
                  <option value="low">Faible Priorité</option>
                  <option value="medium">Priorité Moyenne</option>
                  <option value="high">Haute Priorité</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3">
              <button type="submit" className="btn-primary">
                Créer l'Annonce
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="btn-outline"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Liste des annonces */}
      {filteredAnnouncements.length === 0 ? (
        <div className="text-center py-12">
          <Megaphone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">
            {selectedGroupId ? 'Aucune annonce pour ce groupe' : 'Aucune annonce créée pour le moment'}
          </p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="btn-primary"
          >
            Créer Votre Première Annonce
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredAnnouncements.map((announcement) => {
            const group = announcement.groupId ? groups.find(g => g.id === announcement.groupId) : null;
            const PriorityIcon = getPriorityIcon(announcement.priority);
            
            return (
              <div key={announcement.id} className="card">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{announcement.title}</h3>
                    <p className="text-gray-600 mb-3">{announcement.content}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div>
                        Cible : {group ? group.name : 'Tous les Groupes'}
                      </div>
                      <div>
                        Publié le {format(announcement.createdAt, 'dd MMM yyyy HH:mm')}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`flex items-center gap-1 px-2 py-1 text-xs rounded-full font-medium ${getPriorityColor(announcement.priority)}`}>
                      {PriorityIcon}
                      {getPriorityLabel(announcement.priority)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}