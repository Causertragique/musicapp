import React, { useState } from 'react';
import { 
  Users, 
  Music, 
  MessageSquare, 
  Megaphone, 
  Plus, 
  LogOut,
  Filter,
  Calendar,
  Clock,
  ChevronDown,
  User,
  Settings,
  UserPlus,
  BookOpen,
  FileText,
  ChevronLeft,
  ChevronRight,
  DollarSign
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, isSameDay, addMonths, subMonths } from 'date-fns';
import { fr } from 'date-fns/locale';
import GroupManager from './GroupManager';
import HomeworkManager from './HomeworkManager';
import ChatCenter from './ChatCenter';
import AnnouncementManager from './AnnouncementManager';
import TeacherProfile from './TeacherProfile';
import StudentManager from './StudentManager';
import AssignmentManager from './AssignmentManager';
import CourseNotesManager from './CourseNotesManager';
import FinanceManager from './FinanceManager';

type TabType = 'homework' | 'messages' | 'announcements' | 'profile' | 'groups' | 'students' | 'assignments' | 'notes' | 'finance';

export default function TeacherDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('homework');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');
  const [currentDate, setCurrentDate] = useState(new Date());
  const { user, logout } = useAuth();
  const { groups, homework, messages, announcements, assignments, courseNotes, purchases, getStudentsByGroup } = useData();

  const teacherGroups = groups.filter(group => group.teacherId === user?.id);
  const selectedGroup = selectedGroupId ? groups.find(g => g.id === selectedGroupId) : null;
  
  // Filter data based on selected group
  const filteredHomework = selectedGroupId 
    ? homework.filter(hw => hw.groupId === selectedGroupId)
    : homework.filter(hw => hw.teacherId === user?.id);
  
  const filteredMessages = selectedGroupId
    ? messages.filter(msg => msg.groupId === selectedGroupId)
    : messages.filter(msg => msg.senderId === user?.id);
    
  const filteredAnnouncements = selectedGroupId
    ? announcements.filter(ann => ann.groupId === selectedGroupId)
    : announcements.filter(ann => ann.teacherId === user?.id);

  const filteredAssignments = selectedGroupId
    ? assignments.filter(assign => assign.groupIds.includes(selectedGroupId))
    : assignments.filter(assign => assign.teacherId === user?.id);

  const filteredCourseNotes = selectedGroupId
    ? courseNotes.filter(note => !note.groupId || note.groupId === selectedGroupId)
    : courseNotes.filter(note => note.teacherId === user?.id);

  const filteredPurchases = selectedGroupId
    ? purchases.filter(purchase => purchase.groupId === selectedGroupId)
    : purchases.filter(purchase => purchase.teacherId === user?.id);

  // Calendar functions
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const goToPreviousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  // Get events for a specific day
  const getEventsForDay = (day: Date) => {
    const events = [];
    
    // Add homework due dates
    const homeworkDue = homework.filter(hw => 
      hw.teacherId === user?.id && isSameDay(hw.dueDate, day)
    );
    events.push(...homeworkDue.map(hw => ({ type: 'homework', title: hw.title, color: 'bg-blue-500' })));
    
    // Add assignment due dates
    const assignmentsDue = assignments.filter(assign => 
      assign.teacherId === user?.id && isSameDay(assign.dueDate, day)
    );
    events.push(...assignmentsDue.map(assign => ({ type: 'assignment', title: assign.title, color: 'bg-green-500' })));
    
    return events;
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'homework':
        return <HomeworkManager selectedGroupId={selectedGroupId} />;
      case 'messages':
        return <ChatCenter selectedGroupId={selectedGroupId} />;
      case 'announcements':
        return <AnnouncementManager selectedGroupId={selectedGroupId} />;
      case 'profile':
        return <TeacherProfile />;
      case 'groups':
        return <GroupManager selectedGroupId={selectedGroupId} />;
      case 'students':
        return <StudentManager selectedGroupId={selectedGroupId} />;
      case 'assignments':
        return <AssignmentManager selectedGroupId={selectedGroupId} />;
      case 'notes':
        return <CourseNotesManager selectedGroupId={selectedGroupId} />;
      case 'finance':
        return <FinanceManager selectedGroupId={selectedGroupId} />;
      default:
        return null;
    }
  };

  const getGroupStats = (groupId: string) => {
    const students = getStudentsByGroup(groupId);
    const groupHomework = homework.filter(hw => hw.groupId === groupId);
    const activeHomework = groupHomework.filter(hw => hw.dueDate > new Date());
    const groupMessages = messages.filter(msg => msg.groupId === groupId);
    const groupAnnouncements = announcements.filter(ann => ann.groupId === groupId);
    const groupAssignments = assignments.filter(assign => assign.groupIds.includes(groupId));
    
    return {
      studentCount: students.length,
      homeworkCount: activeHomework.length,
      messageCount: groupMessages.length,
      announcementCount: groupAnnouncements.length,
      assignmentCount: groupAssignments.length
    };
  };

  // Calculate finance statistics
  const totalSales = filteredPurchases
    .filter(p => p.status === 'paid')
    .reduce((total, purchase) => total + purchase.amount, 0);

  const totalCredit = filteredPurchases
    .filter(p => p.status === 'credit')
    .reduce((total, purchase) => total + purchase.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* En-tête */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              {user?.picture && (
                <img
                  src={user.picture}
                  alt="Photo de profil"
                  className="w-10 h-10 rounded-full object-cover"
                />
              )}
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {user?.firstName} {user?.lastName}
                </h1>
                <p className="text-sm text-gray-600">Professeur de Musique</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={logout}
                className="btn-outline flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Déconnexion
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Barre latérale */}
          <div className="lg:w-80 flex-shrink-0 space-y-6">
            {/* Sélecteur de groupe */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Filter className="w-5 h-5 text-primary-500" />
                Sélectionner un Groupe
              </h3>
              
              <div className="relative">
                <select
                  value={selectedGroupId}
                  onChange={(e) => setSelectedGroupId(e.target.value)}
                  className="w-full input appearance-none pr-10"
                >
                  <option value="">Tous les Groupes</option>
                  {teacherGroups.map((group) => (
                    <option key={group.id} value={group.id}>
                      Groupe {group.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
              
              {selectedGroup && (
                <div className="mt-4 p-3 bg-primary-50 rounded-lg">
                  <p className="text-sm font-medium text-primary-900">Groupe {selectedGroup.name}</p>
                  <p className="text-xs text-primary-700 mt-1">{selectedGroup.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-primary-600">
                    <span>{getStudentsByGroup(selectedGroup.id).length} élèves</span>
                    <span>{getGroupStats(selectedGroup.id).homeworkCount} pratiques</span>
                  </div>
                </div>
              )}
            </div>

            {/* Boutons de catégories */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-900 mb-4">Catégories</h3>
              
              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={() => setActiveTab('homework')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'homework'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Music className="w-5 h-5" />
                    <span className="font-medium">Pratique</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredHomework.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('assignments')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'assignments'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5" />
                    <span className="font-medium">Devoir</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredAssignments.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('notes')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'notes'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-5 h-5" />
                    <span className="font-medium">Notes de cours</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredCourseNotes.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('finance')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'finance'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <DollarSign className="w-5 h-5" />
                    <span className="font-medium">Finance</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredPurchases.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('messages')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'messages'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-5 h-5" />
                    <span className="font-medium">Chat</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredMessages.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('announcements')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'announcements'
                      ? 'bg-primary-100 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Megaphone className="w-5 h-5" />
                    <span className="font-medium">Annonces</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {filteredAnnouncements.length}
                  </span>
                </button>
              </div>
            </div>

            {/* Calendrier mensuel */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary-500" />
                  {format(currentDate, 'MMMM yyyy', { locale: fr })}
                </h3>
                <div className="flex items-center gap-1">
                  <button
                    onClick={goToPreviousMonth}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={goToToday}
                    className="px-2 py-1 text-xs bg-primary-100 text-primary-700 rounded hover:bg-primary-200"
                  >
                    Aujourd'hui
                  </button>
                  <button
                    onClick={goToNextMonth}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Jours de la semaine */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((day, index) => (
                  <div key={index} className="text-center text-xs font-medium text-gray-500 py-1">
                    {day}
                  </div>
                ))}
              </div>

              {/* Jours du mois */}
              <div className="grid grid-cols-7 gap-1">
                {/* Jours vides au début du mois */}
                {Array.from({ length: (monthStart.getDay() + 6) % 7 }).map((_, index) => (
                  <div key={`empty-${index}`} className="h-8"></div>
                ))}
                
                {/* Jours du mois */}
                {monthDays.map((day) => {
                  const events = getEventsForDay(day);
                  const isCurrentDay = isToday(day);
                  
                  return (
                    <div
                      key={day.toISOString()}
                      className={`h-8 flex items-center justify-center text-xs relative ${
                        isCurrentDay
                          ? 'bg-primary-500 text-white rounded-full font-medium'
                          : 'text-gray-700 hover:bg-gray-100 rounded'
                      }`}
                    >
                      <span>{format(day, 'd')}</span>
                      {events.length > 0 && (
                        <div className="absolute bottom-0 right-0 w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Légende */}
              <div className="mt-3 pt-3 border-t border-gray-200">
                <div className="flex items-center gap-2 text-xs text-gray-600">
                  <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                  <span>Échéances</span>
                </div>
              </div>
            </div>

            {/* Boutons de gestion */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-900 mb-4">Gestion</h3>
              
              <div className="grid grid-cols-1 gap-3">
                <button
                  onClick={() => setActiveTab('students')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'students'
                      ? 'bg-green-100 text-green-700 border border-green-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <UserPlus className="w-5 h-5" />
                    <span className="font-medium">Gérer les Élèves</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('groups')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'groups'
                      ? 'bg-blue-100 text-blue-700 border border-blue-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Settings className="w-5 h-5" />
                    <span className="font-medium">Gérer les Groupes</span>
                  </div>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-600">
                    {teacherGroups.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('profile')}
                  className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                    activeTab === 'profile'
                      ? 'bg-purple-100 text-purple-700 border border-purple-200'
                      : 'text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5" />
                    <span className="font-medium">Mon Profil</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Statistiques rapides */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <h3 className="text-sm font-medium text-gray-700 mb-3">
                {selectedGroup ? `Statistiques - Groupe ${selectedGroup.name}` : 'Statistiques Générales'}
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Total Élèves</span>
                  <span className="font-medium">
                    {selectedGroup 
                      ? getStudentsByGroup(selectedGroup.id).length
                      : teacherGroups.reduce((acc, group) => acc + getStudentsByGroup(group.id).length, 0)
                    }
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Groupes Actifs</span>
                  <span className="font-medium">{selectedGroup ? 1 : teacherGroups.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Pratiques Actives</span>
                  <span className="font-medium">
                    {selectedGroup
                      ? homework.filter(hw => hw.groupId === selectedGroup.id && hw.dueDate > new Date()).length
                      : homework.filter(hw => hw.dueDate > new Date()).length
                    }
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Devoirs Actifs</span>
                  <span className="font-medium">
                    {selectedGroup
                      ? assignments.filter(assign => assign.groupIds.includes(selectedGroup.id) && assign.dueDate > new Date()).length
                      : assignments.filter(assign => assign.dueDate > new Date()).length
                    }
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Notes de Cours</span>
                  <span className="font-medium">{filteredCourseNotes.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Ventes</span>
                  <span className="font-medium text-green-600">{totalSales.toFixed(2)} $ CAD</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Crédits</span>
                  <span className="font-medium text-red-600">{totalCredit.toFixed(2)} $ CAD</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contenu principal */}
          <div className="flex-1">
            {/* En-tête du contenu */}
            <div className="mb-6">
              {selectedGroup && activeTab !== 'groups' && activeTab !== 'students' && activeTab !== 'profile' && (
                <div className="bg-primary-50 border border-primary-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-primary-600" />
                    <span className="font-medium text-primary-900">
                      Vue filtrée pour le Groupe {selectedGroup.name}
                    </span>
                  </div>
                  <p className="text-primary-700 text-sm mt-1">
                    Toutes les données affichées concernent uniquement ce groupe.
                  </p>
                </div>
              )}
            </div>
            
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}