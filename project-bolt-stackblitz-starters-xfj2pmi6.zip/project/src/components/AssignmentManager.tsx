import React, { useState } from 'react';
import { Plus, BookOpen, Calendar, Clock, Users, Eye, User, FileText, Presentation, Search, X, Music, Mic, Video, Volume2, Pi as Piano, Check, ChevronDown, ChevronUp, Star, MessageSquare, Save, Edit } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { format, isAfter } from 'date-fns';

interface AssignmentManagerProps {
  selectedGroupId?: string;
}

export default function AssignmentManager({ selectedGroupId }: AssignmentManagerProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [viewingSubmissions, setViewingSubmissions] = useState<string | null>(null);
  const [viewingSubmissionDetail, setViewingSubmissionDetail] = useState<string | null>(null);
  const [evaluatingSubmission, setEvaluatingSubmission] = useState<string | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<string>('');
  const [selectedStudents, setSelectedStudents] = useState<string>('all');
  const { user } = useAuth();
  const { groups, assignments, addAssignment, users, evaluateAssignment } = useData();

  const teacherGroups = groups.filter(group => group.teacherId === user?.id);
  const filteredAssignments = selectedGroupId 
    ? assignments.filter(assign => assign.groupIds.includes(selectedGroupId))
    : assignments.filter(assign => assign.teacherId === user?.id);

  const handleCreateAssignment = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    // Determine assigned students based on selection
    let assignedStudentIds: string[] = [];
    if (selectedGroup) {
      const groupStudents = getStudentsByGroup(selectedGroup);
      if (selectedStudents === 'all') {
        assignedStudentIds = groupStudents.map(s => s.id);
      } else {
        assignedStudentIds = [selectedStudents];
      }
    }
    
    addAssignment({
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      dueDate: new Date(formData.get('dueDate') as string),
      groupIds: selectedGroup ? [selectedGroup] : [],
      assignedStudentIds,
      teacherId: user?.id || '',
      type: formData.get('type') as 'theory' | 'audio_recording' | 'video_recording' | 'solfege_dictation' | 'instrumental' | 'other',
      maxPoints: parseInt(formData.get('maxPoints') as string)
    });

    setShowCreateForm(false);
    setSelectedGroup('');
    setSelectedStudents('all');
    e.currentTarget.reset();
  };

  const handleGroupChange = (groupId: string) => {
    setSelectedGroup(groupId);
    setSelectedStudents('all'); // Reset to "all students" when group changes
  };

  const handleEvaluateSubmission = (submissionId: string, grade: number, feedback: string) => {
    evaluateAssignment(submissionId, grade, feedback);
    setEvaluatingSubmission(null);
  };

  const getAssignmentStats = (assignment: any) => {
    const totalStudents = assignment.assignedStudentIds.length;
    const submittedCount = assignment.submissions.length;
    const evaluatedCount = assignment.submissions.filter((sub: any) => sub.grade !== undefined).length;
    const isOverdue = isAfter(new Date(), assignment.dueDate);
    
    return { totalStudents, submittedCount, evaluatedCount, isOverdue };
  };

  const getStudentName = (studentId: string) => {
    const student = users.find(u => u.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : `Élève ${studentId}`;
  };

  const getStudentPicture = (studentId: string) => {
    const student = users.find(u => u.id === studentId);
    return student?.picture;
  };

  const getStudentsByGroup = (groupId: string) => {
    const group = groups.find(g => g.id === groupId);
    if (!group) return [];
    return users.filter(u => group.studentIds.includes(u.id));
  };

  const getGroupName = (groupId: string) => {
    const group = groups.find(g => g.id === groupId);
    return group ? group.name : 'Groupe inconnu';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'theory':
        return <BookOpen className="w-4 h-4" />;
      case 'audio_recording':
        return <Mic className="w-4 h-4" />;
      case 'video_recording':
        return <Video className="w-4 h-4" />;
      case 'solfege_dictation':
        return <Volume2 className="w-4 h-4" />;
      case 'instrumental':
        return <Piano className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'theory':
        return 'Théorie';
      case 'audio_recording':
        return 'Enregistrement Audio';
      case 'video_recording':
        return 'Enregistrement Vidéo';
      case 'solfege_dictation':
        return 'Solfège/Dictée';
      case 'instrumental':
        return 'Instrumental';
      default:
        return 'Autre';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'theory':
        return 'bg-blue-100 text-blue-800';
      case 'audio_recording':
        return 'bg-green-100 text-green-800';
      case 'video_recording':
        return 'bg-purple-100 text-purple-800';
      case 'solfege_dictation':
        return 'bg-orange-100 text-orange-800';
      case 'instrumental':
        return 'bg-pink-100 text-pink-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getGradeColor = (grade: number, maxPoints: number) => {
    const percentage = (grade / maxPoints) * 100;
    if (percentage >= 90) return 'text-green-600';
    if (percentage >= 80) return 'text-blue-600';
    if (percentage >= 70) return 'text-yellow-600';
    if (percentage >= 60) return 'text-orange-600';
    return 'text-red-600';
  };

  const getGradeLabel = (grade: number, maxPoints: number) => {
    const percentage = (grade / maxPoints) * 100;
    if (percentage >= 90) return 'Excellent';
    if (percentage >= 80) return 'Très bien';
    if (percentage >= 70) return 'Bien';
    if (percentage >= 60) return 'Satisfaisant';
    return 'À améliorer';
  };

  // Get students for the selected group
  const groupStudents = selectedGroup ? getStudentsByGroup(selectedGroup) : [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">
          {selectedGroupId ? `Devoirs - Groupe ${groups.find(g => g.id === selectedGroupId)?.name}` : 'Gestion des Devoirs'}
        </h2>
        <button
          onClick={() => setShowCreateForm(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Créer un Devoir
        </button>
      </div>

      {/* Formulaire de création de devoir */}
      {showCreateForm && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Créer un Nouveau Devoir</h3>
          <form onSubmit={handleCreateAssignment} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                Titre du Devoir
              </label>
              <input
                type="text"
                id="title"
                name="title"
                className="input"
                placeholder="ex: Analyse harmonique, Enregistrement d'une gamme, Dictée mélodique"
                required
              />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Description et Consignes
              </label>
              <textarea
                id="description"
                name="description"
                className="textarea"
                rows={4}
                placeholder="Décrivez les objectifs, les consignes détaillées, les critères d'évaluation..."
                required
              />
            </div>

            {/* Sélection du groupe et des élèves avec menus déroulants */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="groupSelect" className="block text-sm font-medium text-gray-700 mb-2">
                  Assigner au Groupe
                </label>
                <select
                  id="groupSelect"
                  value={selectedGroup}
                  onChange={(e) => handleGroupChange(e.target.value)}
                  className="input"
                  required
                >
                  <option value="">Sélectionner un groupe</option>
                  {teacherGroups.map((group) => (
                    <option key={group.id} value={group.id}>
                      Groupe {group.name} ({getStudentsByGroup(group.id).length} élèves)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="studentSelect" className="block text-sm font-medium text-gray-700 mb-2">
                  Sélectionner les Élèves
                </label>
                <select
                  id="studentSelect"
                  value={selectedStudents}
                  onChange={(e) => setSelectedStudents(e.target.value)}
                  className="input"
                  disabled={!selectedGroup}
                  required
                >
                  <option value="all">
                    Tous les élèves ({groupStudents.length})
                  </option>
                  {groupStudents.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.firstName} {student.lastName} ({student.instrument})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Aperçu de l'assignation */}
            {selectedGroup && (
              <div className="p-3 bg-primary-50 border border-primary-200 rounded-lg">
                <h4 className="text-sm font-medium text-primary-900 mb-2">Aperçu de l'Assignation</h4>
                <div className="text-sm text-primary-700">
                  <p><strong>Groupe :</strong> {getGroupName(selectedGroup)}</p>
                  <p><strong>Élèves assignés :</strong> {
                    selectedStudents === 'all' 
                      ? `Tous les élèves (${groupStudents.length})`
                      : getStudentName(selectedStudents)
                  }</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-2">
                  Type de Devoir
                </label>
                <select
                  id="type"
                  name="type"
                  className="input"
                  required
                >
                  <option value="theory">Théorie</option>
                  <option value="audio_recording">Enregistrement Audio</option>
                  <option value="video_recording">Enregistrement Vidéo</option>
                  <option value="solfege_dictation">Solfège/Dictée</option>
                  <option value="instrumental">Instrumental</option>
                  <option value="other">Autre</option>
                </select>
              </div>
              <div>
                <label htmlFor="maxPoints" className="block text-sm font-medium text-gray-700 mb-2">
                  Points Maximum
                </label>
                <input
                  type="number"
                  id="maxPoints"
                  name="maxPoints"
                  className="input"
                  placeholder="100"
                  min="1"
                  max="1000"
                  defaultValue="100"
                  required
                />
              </div>
            </div>
            <div>
              <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 mb-2">
                Date et Heure Limite
              </label>
              <input
                type="datetime-local"
                id="dueDate"
                name="dueDate"
                className="input"
                required
              />
            </div>
            <div className="flex gap-3">
              <button 
                type="submit" 
                className="btn-primary"
                disabled={!selectedGroup}
              >
                Créer le Devoir
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowCreateForm(false);
                  setSelectedGroup('');
                  setSelectedStudents('all');
                }}
                className="btn-outline"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Liste des devoirs */}
      {filteredAssignments.length === 0 ? (
        <div className="text-center py-12">
          <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">
            {selectedGroupId ? 'Aucun devoir assigné à ce groupe pour le moment' : 'Aucun devoir créé pour le moment'}
          </p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="btn-primary"
          >
            Créer Votre Premier Devoir
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {filteredAssignments.map((assignment) => {
            const stats = getAssignmentStats(assignment);
            const TypeIcon = getTypeIcon(assignment.type);

            return (
              <div key={assignment.id} className="card">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{assignment.title}</h3>
                      <span className={`flex items-center gap-1 px-2 py-1 text-xs rounded-full font-medium ${getTypeColor(assignment.type)}`}>
                        {TypeIcon}
                        {getTypeLabel(assignment.type)}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-3">{assignment.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {assignment.groupIds.length > 1 
                          ? `${assignment.groupIds.length} groupes`
                          : `Groupe ${getGroupName(assignment.groupIds[0])}`
                        }
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {assignment.assignedStudentIds.length} élève{assignment.assignedStudentIds.length > 1 ? 's' : ''}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Échéance : {format(assignment.dueDate, 'dd MMM yyyy')}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {format(assignment.dueDate, 'HH:mm')}
                      </div>
                      <div className="flex items-center gap-1">
                        <BookOpen className="w-4 h-4" />
                        {assignment.maxPoints} points
                      </div>
                    </div>
                    
                    {/* Affichage des groupes et élèves assignés */}
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Assigné à :</h4>
                      <div className="space-y-2">
                        {assignment.groupIds.map(groupId => {
                          const groupStudents = getStudentsByGroup(groupId);
                          const assignedStudentsInGroup = groupStudents.filter(s => assignment.assignedStudentIds.includes(s.id));
                          
                          return (
                            <div key={groupId} className="text-sm">
                              <span className="font-medium">Groupe {getGroupName(groupId)} :</span>
                              <span className="ml-2 text-gray-600">
                                {assignedStudentsInGroup.length === groupStudents.length 
                                  ? 'Tous les élèves'
                                  : `${assignedStudentsInGroup.length}/${groupStudents.length} élèves`
                                }
                              </span>
                              {assignedStudentsInGroup.length < groupStudents.length && (
                                <div className="ml-4 mt-1 text-xs text-gray-500">
                                  {assignedStudentsInGroup.map(s => `${s.firstName} ${s.lastName}`).join(', ')}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                    stats.isOverdue ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                  }`}>
                    {stats.isOverdue ? 'Échéance dépassée' : 'Actif'}
                  </div>
                </div>

                {/* Statistiques de soumission et d'évaluation */}
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">{stats.submittedCount}</div>
                        <div className="text-sm text-gray-600">Soumis</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{stats.evaluatedCount}</div>
                        <div className="text-sm text-blue-600">Évalués</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-600">{stats.submittedCount - stats.evaluatedCount}</div>
                        <div className="text-sm text-yellow-600">En attente</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">{stats.totalStudents - stats.submittedCount}</div>
                        <div className="text-sm text-gray-600">Non soumis</div>
                      </div>
                    </div>
                    <button
                      onClick={() => setViewingSubmissions(viewingSubmissions === assignment.id ? null : assignment.id)}
                      className="btn-outline flex items-center gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      Voir les Soumissions
                    </button>
                  </div>

                  {/* Barres de progression */}
                  <div className="mt-4 space-y-2">
                    <div>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Soumissions</span>
                        <span>{Math.round((stats.submittedCount / stats.totalStudents) * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${(stats.submittedCount / stats.totalStudents) * 100}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Évaluations</span>
                        <span>{stats.submittedCount > 0 ? Math.round((stats.evaluatedCount / stats.submittedCount) * 100) : 0}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${stats.submittedCount > 0 ? (stats.evaluatedCount / stats.submittedCount) * 100 : 0}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Détail des soumissions */}
                {viewingSubmissions === assignment.id && (
                  <div className="border-t border-gray-200 pt-4">
                    <h4 className="font-medium text-gray-900 mb-3">Soumissions des Devoirs</h4>
                    {assignment.submissions.length === 0 ? (
                      <p className="text-gray-500 text-sm">Aucune soumission pour le moment</p>
                    ) : (
                      <div className="space-y-4">
                        {assignment.submissions.map((submission: any) => {
                          const studentPicture = getStudentPicture(submission.studentId);
                          const isEvaluating = evaluatingSubmission === submission.id;
                          
                          return (
                            <div key={submission.id} className="bg-white border border-gray-200 rounded-lg p-4">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-200 flex items-center justify-center">
                                    {studentPicture ? (
                                      <img
                                        src={studentPicture}
                                        alt="Photo de l'élève"
                                        className="w-full h-full object-cover"
                                      />
                                    ) : (
                                      <User className="w-5 h-5 text-gray-400" />
                                    )}
                                  </div>
                                  <div>
                                    <p className="font-medium text-gray-900">{getStudentName(submission.studentId)}</p>
                                    <p className="text-sm text-gray-600">
                                      Soumis le {format(submission.submittedAt, 'dd MMM yyyy HH:mm')}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-3">
                                  {submission.grade !== undefined ? (
                                    <div className="text-right">
                                      <div className={`text-lg font-bold ${getGradeColor(submission.grade, assignment.maxPoints)}`}>
                                        {submission.grade}/{assignment.maxPoints}
                                      </div>
                                      <div className={`text-xs ${getGradeColor(submission.grade, assignment.maxPoints)}`}>
                                        {getGradeLabel(submission.grade, assignment.maxPoints)}
                                      </div>
                                    </div>
                                  ) : (
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-sm font-medium">
                                      En attente d'évaluation
                                    </span>
                                  )}
                                  {!isEvaluating && (
                                    <button
                                      onClick={() => setEvaluatingSubmission(submission.id)}
                                      className="btn-outline text-sm flex items-center gap-1"
                                    >
                                      {submission.grade !== undefined ? <Edit className="w-3 h-3" /> : <Star className="w-3 h-3" />}
                                      {submission.grade !== undefined ? 'Modifier' : 'Évaluer'}
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setViewingSubmissionDetail(viewingSubmissionDetail === submission.id ? null : submission.id)}
                                    className="btn-outline text-sm flex items-center gap-1"
                                  >
                                    <Eye className="w-3 h-3" />
                                    {viewingSubmissionDetail === submission.id ? 'Masquer' : 'Voir'}
                                  </button>
                                </div>
                              </div>

                              {/* Formulaire d'évaluation */}
                              {isEvaluating && (
                                <EvaluationForm
                                  submission={submission}
                                  maxPoints={assignment.maxPoints}
                                  onSubmit={(grade, feedback) => handleEvaluateSubmission(submission.id, grade, feedback)}
                                  onCancel={() => setEvaluatingSubmission(null)}
                                />
                              )}

                              {/* Détail de la soumission */}
                              {viewingSubmissionDetail === submission.id && !isEvaluating && (
                                <div className="mt-4 space-y-4">
                                  <div className="bg-gray-50 rounded p-4">
                                    <h5 className="font-medium text-gray-900 mb-2">Contenu de la Soumission</h5>
                                    <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                                      {submission.content}
                                    </p>
                                  </div>

                                  {submission.attachments && submission.attachments.length > 0 && (
                                    <div className="bg-blue-50 rounded p-4">
                                      <h5 className="font-medium text-blue-900 mb-2">Fichiers Joints</h5>
                                      <div className="space-y-1">
                                        {submission.attachments.map((attachment: string, index: number) => (
                                          <div key={index} className="flex items-center gap-2 text-blue-700">
                                            <FileText className="w-4 h-4" />
                                            <span className="text-sm">{attachment}</span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {submission.feedback && (
                                    <div className="bg-green-50 rounded p-4">
                                      <h5 className="font-medium text-green-900 mb-2">Commentaire du Professeur</h5>
                                      <p className="text-green-800">{submission.feedback}</p>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Composant pour le formulaire d'évaluation
function EvaluationForm({ 
  submission, 
  maxPoints, 
  onSubmit, 
  onCancel 
}: { 
  submission: any; 
  maxPoints: number; 
  onSubmit: (grade: number, feedback: string) => void; 
  onCancel: () => void; 
}) {
  const [grade, setGrade] = useState(submission.grade || '');
  const [feedback, setFeedback] = useState(submission.feedback || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (grade === '' || isNaN(Number(grade))) return;
    onSubmit(Number(grade), feedback);
  };

  const getGradeColor = (gradeValue: number) => {
    const percentage = (gradeValue / maxPoints) * 100;
    if (percentage >= 90) return 'border-green-500 bg-green-50';
    if (percentage >= 80) return 'border-blue-500 bg-blue-50';
    if (percentage >= 70) return 'border-yellow-500 bg-yellow-50';
    if (percentage >= 60) return 'border-orange-500 bg-orange-50';
    return 'border-red-500 bg-red-50';
  };

  const getGradeLabel = (gradeValue: number) => {
    const percentage = (gradeValue / maxPoints) * 100;
    if (percentage >= 90) return 'Excellent';
    if (percentage >= 80) return 'Très bien';
    if (percentage >= 70) return 'Bien';
    if (percentage >= 60) return 'Satisfaisant';
    return 'À améliorer';
  };

  return (
    <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
      <h5 className="font-medium text-blue-900 mb-4 flex items-center gap-2">
        <Star className="w-5 h-5" />
        Évaluation du Devoir
      </h5>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="grade" className="block text-sm font-medium text-gray-700 mb-2">
              Note (sur {maxPoints} points)
            </label>
            <input
              type="number"
              id="grade"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className={`input ${grade ? getGradeColor(Number(grade)) : ''}`}
              min="0"
              max={maxPoints}
              step="0.5"
              placeholder={`0 - ${maxPoints}`}
              required
            />
            {grade && !isNaN(Number(grade)) && (
              <p className="text-sm mt-1 font-medium">
                {Math.round((Number(grade) / maxPoints) * 100)}% - {getGradeLabel(Number(grade))}
              </p>
            )}
          </div>
          
          <div className="flex items-center">
            <div className="text-sm text-gray-600">
              <p><strong>Barème suggéré :</strong></p>
              <p>• 90-100% : Excellent</p>
              <p>• 80-89% : Très bien</p>
              <p>• 70-79% : Bien</p>
              <p>• 60-69% : Satisfaisant</p>
              <p>• &lt;60% : À améliorer</p>
            </div>
          </div>
        </div>

        <div>
          <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-2">
            Commentaires et Rétroaction
          </label>
          <textarea
            id="feedback"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            className="textarea"
            rows={4}
            placeholder="Donnez des commentaires constructifs sur le travail de l'élève : points forts, axes d'amélioration, conseils pour progresser..."
          />
        </div>

        <div className="flex gap-3">
          <button
            type="submit"
            className="btn-primary flex items-center gap-2"
            disabled={!grade || isNaN(Number(grade))}
          >
            <Save className="w-4 h-4" />
            Enregistrer l'Évaluation
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="btn-outline flex items-center gap-2"
          >
            <X className="w-4 h-4" />
            Annuler
          </button>
        </div>
      </form>
    </div>
  );
}