import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import TeacherDashboard from './components/TeacherDashboard';
import StudentDashboard from './components/StudentDashboard';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { SettingsProvider } from './contexts/SettingsContext';

function AppRoutes() {
  const { user } = useAuth();

  if (!user) {
    return <LoginPage />;
  }

  return (
    <Routes>
      <Route 
        path="/" 
        element={
          user.role === 'teacher' ? (
            <Navigate to="/teacher" replace />
          ) : (
            <Navigate to="/student" replace />
          )
        } 
      />
      <Route 
        path="/teacher" 
        element={
          user.role === 'teacher' ? (
            <TeacherDashboard />
          ) : (
            <Navigate to="/student" replace />
          )
        } 
      />
      <Route 
        path="/student" 
        element={
          user.role === 'student' ? (
            <StudentDashboard />
          ) : (
            <Navigate to="/teacher" replace />
          )
        } 
      />
    </Routes>
  );
}

function App() {
  return (
    <Router>
      <SettingsProvider>
        <AuthProvider>
          <DataProvider>
            <div className="min-h-screen bg-gray-50">
              <AppRoutes />
            </div>
          </DataProvider>
        </AuthProvider>
      </SettingsProvider>
    </Router>
  );
}

export default App;